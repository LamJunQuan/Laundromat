Python 3.11

Admin ID and Password
admin@123.com  admin123
shermangoh2005@gmail.com  Sherman123!
timfeng029@gmail.com  Timfeng123!
hanshujie2001@gmail.com  Shujie123!
2005junquan@gmail.com  Junquan123!

Customer ID and Password
hanshujie2001@gmail.com  Shujie123!
mmohnish04@gmail.com  Mohnish123!
timfeng029@gmail.com  Timfeng123!
shermangoh2005@gmail.com  Sherman123!
2005junquan@gmail.com  Junquan123!

Installed packages
pip install flask  V3.0.0
pip install wtforms  V3.1.1
pip install Flask-Bcrypt  V1.0.1
pip install email_validator  V2.1.0.post1
pip install Flask-WTF  V3.1.1
pip install Werkzeug  V3.0.1
pip install bcrypt  V4.1.2
pip install requests  V2.31.0
